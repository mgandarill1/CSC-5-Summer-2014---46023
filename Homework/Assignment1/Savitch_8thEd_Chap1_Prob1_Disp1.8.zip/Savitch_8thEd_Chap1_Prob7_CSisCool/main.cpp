/* 
 * File:   main.cpp
 * Author: Mayra Gandarilla
 * Created on June 25, 2014, 11:18 PM
 */

//System Level Libraries
#include <iostream>
using namespace std;

// User Defined Libraries

// Global Constants

// Function Prototype

//Execution Begins Here!
int main(int argc, char** argv) {
    cout <<"***************************************************************************************************\n" << endl;
    cout <<"             C C C                     S S S S              !!\n";
    cout <<"           C       C                  S        S            !!\n";
    cout <<"          C                          S                      !!\n";
    cout <<"         C                            S                     !!\n";
    cout <<"         C                             S S S S              !!\n";
    cout <<"         C                                     S            !!\n";
    cout <<"          C                                     S           !!\n";
    cout <<"           C       C                 S         S              \n";
    cout <<"             C C C                     S S S S              00\n" << endl;
    cout <<"**************************************************************************************************\n" << endl;
    cout <<"         COMPUTER SCIENCE IS COOL STUFF!!!!!!!!!!!\n";
    
    //Exit Stage Right
    
    return 0;
}

