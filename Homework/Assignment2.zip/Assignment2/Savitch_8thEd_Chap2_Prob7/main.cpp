/* 
 * File:   main.cpp
 * Author: Mayra Gandarilla
 * Purpose: Assignment 2
 * Created on July 1, 2014, 11:54 AM
 */

// System Level Libraries
#include <iostream>
using namespace std;

// User Defined Libraries

// Global Constants

//Function Prototypes

// Execution Begins Here!
int main(int argc, char** argv) {
    //Define Variables
    

    return 0;
}

