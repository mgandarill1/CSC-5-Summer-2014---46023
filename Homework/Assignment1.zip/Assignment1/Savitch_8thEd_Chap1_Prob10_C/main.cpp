/* 
 * File:   main.cpp
 * Author: Mayra Gandarilla
 * Created on June 26, 2014, 12:13 AM
 */

// System Level Libraries
#include <iostream>
using namespace std;

//User Defined Libraries

// Global Constants

// Function Prototypes

// Execution Begins Here!
int main(int argc, char** argv) {
    
    int uimp; //User Input
    cout <<"Enter any number or letter.\n";
    cin >> uimp;
    cout << uimp            
    

    return 0;
}

