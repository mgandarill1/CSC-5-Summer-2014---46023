/* 
 * File:   main.cpp
 * Author: Mayra Gandarilla
 * Purpose: First Project
 * Created on June 25, 2014, 10:52 PM
 */

//System Level Libraries
#include <iostream>
using namespace std;

//User Defined Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    
    // Output Simple Text
    cout << " Hello World " << endl;
    //Exit Stage Right!

    return 0;
}

